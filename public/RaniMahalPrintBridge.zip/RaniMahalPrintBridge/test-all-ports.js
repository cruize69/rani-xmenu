// test-all-ports.js — Multi-Protocol Star Printer Diagnostic
import net from "net";

const PRINTER_IP = process.argv[2] || "192.168.2.221";

const ESC = 0x1B;
const GS  = 0x1D;

// Test payload
const buffer = Buffer.concat([
  Buffer.from([ESC, 0x40]),
  Buffer.from("\n\n=== RANI MAHAL TEST TICKET ===\n\n", "utf8"),
  Buffer.from(new Date().toLocaleString() + "\n\n", "utf8"),
  Buffer.from([0x0A, 0x0A, ESC, 0x64, 0x02, GS, 0x56, 0x00, 0x0A])
]);

async function testPort(port, name) {
  return new Promise((resolve) => {
    console.log(`Testing ${name} on Port ${port}...`);
    const socket = new net.Socket();
    socket.setNoDelay(true);
    socket.setTimeout(4000);

    socket.connect(port, PRINTER_IP, () => {
      console.log(`  ✅ Connected to Port ${port}! Sending data...`);
      socket.write(buffer, () => {
        setTimeout(() => {
          socket.end();
          socket.destroy();
          console.log(`  ✅ Port ${port} test payload sent successfully.`);
          resolve(true);
        }, 500);
      });
    });

    socket.on("timeout", () => {
      console.log(`  ❌ Port ${port} timeout.`);
      socket.destroy();
      resolve(false);
    });

    socket.on("error", (err) => {
      console.log(`  ❌ Port ${port} error: ${err.message}`);
      socket.destroy();
      resolve(false);
    });
  });
}

async function run() {
  console.log(`\n🔍 Running Star Printer Multi-Port Test for ${PRINTER_IP}...\n`);
  await testPort(9100, "Port 9100 (Raw Socket)");
  await testPort(9101, "Port 9101 (Star Secondary)");
  await testPort(515,  "Port 515 (LPR/LPD)");
  console.log("\nDone testing ports!");
}

run();
