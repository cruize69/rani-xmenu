====================================================================
👑 Rani Mahal — Windows 11 Thermal Print Bridge Instructions
====================================================================

1. Install Node.js on Windows 11:
   - Download & install Node.js LTS from https://nodejs.org

2. Set Printer IP in print-bridge.js:
   - Open print-bridge.js in Notepad
   - Change '192.168.1.150' to your Star Printer's actual IP address

3. Set your Manager Secret System Variable:
   - Press Win + R, type sysdm.cpl, press Enter
   - Advanced tab -> Environment Variables -> New System Variable
   - Name: MANAGER_SECRET
   - Value: (Your Manager Password)

4. Run the Print Bridge:
   - Double-click 'start-printer.bat'

5. Auto-start on Windows boot (Optional but Recommended):
   - Press Win + R, type shell:startup, press Enter
   - Copy 'start-printer.bat' into that Startup folder!
====================================================================
