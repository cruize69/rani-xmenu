#!/usr/bin/env node
// print-bridge.js — Rani Mahal Restaurant Print Bridge
import net  from "net";
import fs   from "fs";
import path from "path";
import { exec } from "child_process";

// ── Configuration ────────────────────────────────────────────────
const CONFIG = {
  // Ordering system backend URL
  apiBase: process.env.API_BASE ?? "https://ranimahal.food",

  // Manager secret authentication key
  managerSecret: process.env.MANAGER_SECRET ?? "change-me",

  // Printer connection details:
  printer: {
    type: process.env.PRINTER_TYPE ?? "win",       // "win" for Windows Driver, "tcp" for RAW LAN
    winName: process.env.PRINTER_NAME ?? "TSP143", // Windows printer name from Printers & Scanners
    host: process.env.PRINTER_IP ?? "192.168.2.221",
    port: 9100,
  },

  // Polling frequency in milliseconds (default 5000ms = 5s)
  pollMs: 5000,
};
// ─────────────────────────────────────────────────────────────────

let isRunning = false;

async function poll() {
  if (isRunning) return;
  isRunning = true;

  try {
    // Pop an order ID from the print queue
    const res = await fetch(`${CONFIG.apiBase}/api/orders`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-manager-secret": CONFIG.managerSecret,
      },
      body: JSON.stringify({ action: "dequeue" }),
    });

    if (!res.ok) {
      console.error(`[${new Date().toLocaleTimeString()}] Print queue error: ${res.status}`);
      return;
    }

    const { orderId } = await res.json();
    if (!orderId) return; // Queue empty

    console.log(`[${new Date().toLocaleTimeString()}] 🖨️ Printing Order #${orderId.slice(-6).toUpperCase()} to Windows printer '${CONFIG.printer.winName}'...`);

    // Fetch full order object
    const orderRes = await fetch(`${CONFIG.apiBase}/api/orders?id=${orderId}`, {
      headers: { "x-manager-secret": CONFIG.managerSecret },
    });

    if (!orderRes.ok) {
      console.error(`[${new Date().toLocaleTimeString()}] Fetch failed for order ${orderId}: ${orderRes.status}`);
      return;
    }

    const order = await orderRes.json();

    // Send to Windows printer driver or TCP socket
    if (CONFIG.printer.type === "win") {
      const { buildPlainTextReceipt } = await import("./lib/printer.js");
      await sendToWindowsPrinter(CONFIG.printer.winName, buildPlainTextReceipt(order));
    } else {
      const { buildReceipt } = await import("./lib/printer.js");
      await sendToPrinter(buildReceipt(order));
    }

    // Mark order as printed in system database
    await fetch(`${CONFIG.apiBase}/api/orders`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        "x-manager-secret": CONFIG.managerSecret,
      },
      body: JSON.stringify({ id: orderId, printed: true }),
    });

    console.log(`[${new Date().toLocaleTimeString()}] ✅ SUCCESS! Order #${order.id.slice(-6).toUpperCase()} printed & marked.`);

  } catch (err) {
    console.error(`[${new Date().toLocaleTimeString()}] Error: ${err.message}`);
  } finally {
    isRunning = false;
  }
}

function sendToWindowsPrinter(printerName, textContent) {
  return new Promise((resolve, reject) => {
    const tempPath = path.join(process.cwd(), "temp_receipt.txt");
    fs.writeFileSync(tempPath, textContent, "utf8");

    const cmd = `powershell -Command "Get-Content -Path '${tempPath}' | Out-Printer -Name '${printerName}'"`;

    exec(cmd, (err, stdout, stderr) => {
      if (err) {
        console.error("Windows Print Spooler Error:", stderr || err.message);
        reject(err);
      } else {
        resolve();
      }
    });
  });
}

function sendToPrinter(buffer) {
  return new Promise((resolve, reject) => {
    if (CONFIG.printer.type === "tcp") {
      const socket = new net.Socket();
      socket.setNoDelay(true);
      socket.setTimeout(7000);

      socket.connect(CONFIG.printer.port, CONFIG.printer.host, () => {
        socket.write(buffer, () => {
          setTimeout(() => {
            socket.end();
            socket.destroy();
            resolve();
          }, 500);
        });
      });

      socket.on("timeout", () => { socket.destroy(); reject(new Error(`Printer timeout (${CONFIG.printer.host}:${CONFIG.printer.port})`)); });
      socket.on("error", (err) => { socket.destroy(); reject(err); });
    } else {
      fs.writeFile(CONFIG.printer.usbPath, buffer, err => {
        if (err) reject(err);
        else resolve();
      });
    }
  });
}

console.log(`
╔══════════════════════════════════════════════════════╗
║  👑 Rani Mahal — Windows 11 Print Bridge             ║
║  Site:    ${CONFIG.apiBase}                      ║
║  Printer: Windows Driver '${CONFIG.printer.winName}'              ║
║  Poll:    Every ${CONFIG.pollMs / 1000} seconds                         ║
╚══════════════════════════════════════════════════════╝
`);

poll();
setInterval(poll, CONFIG.pollMs);

process.on("SIGINT",  () => { console.log("\nPrint Bridge Stopped."); process.exit(0); });
process.on("SIGTERM", () => { console.log("\nPrint Bridge Stopped."); process.exit(0); });
